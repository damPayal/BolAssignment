//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Library_NavigateHome()
{
	truclient_step("1", "Function HomePage", "snapshot=NavigateHome_1.inf");
	{
		truclient_step("1.1", "Navigate to 'https://www.bol.com/nl/nl/'", "snapshot=NavigateHome_1.1.inf");
		truclient_step("1.2", "Exit Action with status Pass", "snapshot=NavigateHome_1.2.inf");
	}

	return 0;
}
