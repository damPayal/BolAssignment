//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Resize browser window to 1900 px / 1000 px", "snapshot=Action_1.inf");
	lr_start_transaction("TC01_BolAsses_LauchPage");
	truclient_step("2", "Navigate to 'https://www.bol.com/nl/nl/'", "snapshot=Action_2.inf");
	truclient_step("5", "Click on Alles accepteren button", "snapshot=Action_5.inf");
	truclient_step("8", "Wait until Waar ben je naar op zoek? textbox exists", "snapshot=Action_8.inf");
	lr_end_transaction("TC01_BolAsses_LauchPage",0);
	truclient_step("9", "Click on Waar ben je naar op zoek? textbox", "snapshot=Action_9.inf");
	truclient_step("10", "Wait 3 seconds", "snapshot=Action_10.inf");
	lr_start_transaction("TC02_BolAsses_Search");
	truclient_step("13", "Type P_searchItem in Waar ben je naar op zoek? textbox", "snapshot=Action_13.inf");
	truclient_step("15", "Press key Enter on Waar ben je naar op zoek? textbox", "snapshot=Action_15.inf");
	lr_end_transaction("TC02_BolAsses_Search",0);
	truclient_step("16", "If ( document.getElementsByCl...).length > 0; )", "snapshot=Action_16.inf");
	{
	}
	truclient_step("Else");
	{
		truclient_step("16.1", "Evaluate JavaScript code TCA.log('Sorry! We found...g'); TCA.done();", "snapshot=Action_16.1.inf");
		lr_start_transaction("TC03_BolAsses_noSearchResultFound");
		truclient_step("16.2", "Call Function NavigateHome.HomePage", "snapshot=Action_16.2.inf");
		lr_end_transaction("TC03_BolAsses_noSearchResultFound",0);
	}
	truclient_step("17", "Wait 3 seconds", "snapshot=Action_17.inf");
	lr_start_transaction("TC03_BolAsses_numberOfSearchItem");
	truclient_step("18", "Get Visible Text from ItemSearchCount", "snapshot=Action_18.inf");
	lr_end_transaction("TC03_BolAsses_numberOfSearchItem",0);
	truclient_step("19", "Wait 3 seconds", "snapshot=Action_19.inf");
	lr_start_transaction("TC04_BolAsses_JSCode_WithFoundArticles");
	truclient_step("20", "Evaluate JavaScript code var test = TotalResults;...();", "snapshot=Action_20.inf");
	lr_end_transaction("TC04_BolAsses_JSCode_WithFoundArticles",0);
	truclient_step("21", "Wait 3 seconds", "snapshot=Action_21.inf");
	lr_start_transaction("TC05_BolAsses_clickFirstItem");
	truclient_step("22", "Click on FirstItem link", "snapshot=Action_22.inf");
	lr_end_transaction("TC05_BolAsses_clickFirstItem",0);
	truclient_step("23", "Wait 3 seconds", "snapshot=Action_23.inf");
	lr_start_transaction("TC06_BolAsses_gobackResultPage");
	truclient_step("24", "Go Back a page", "snapshot=Action_24.inf");
	lr_end_transaction("TC06_BolAsses_gobackResultPage",0);
	truclient_step("25", "Click on Terug Terug JavaScript link", "snapshot=Action_25.inf");
	truclient_step("26", "Wait 3 seconds", "snapshot=Action_26.inf");
	lr_start_transaction("TC07_BolAsses_clickRandomresult");
	truclient_step("27", "Click on Random link", "snapshot=Action_27.inf");
	lr_end_transaction("TC07_BolAsses_clickRandomresult",0);
	truclient_step("28", "Wait 3 seconds", "snapshot=Action_28.inf");
	lr_start_transaction("TC08_BolAsses_cFunction_randomArticleNo");
	truclient_step("29", "Evaluate C function Action1", "snapshot=Action_29.inf");
	truclient_step("30", "Evaluate JavaScript code var randomIndex=parseInt...ex); TCA.done();", "snapshot=Action_30.inf");
	lr_end_transaction("TC08_BolAsses_cFunction_randomArticleNo",0);
	truclient_step("31", "Click on Terug Terug JavaScript link", "snapshot=Action_31.inf");
	truclient_step("32", "Call Function NavigateHome.HomePage", "snapshot=Action_32.inf");

	return 0;
}
