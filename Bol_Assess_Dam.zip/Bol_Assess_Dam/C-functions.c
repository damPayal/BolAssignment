//
// To view/edit the script, click the Develop Script button
//
// This file defines the data and functions that will be used by EvalC
// steps in the script
//
// Note: this file is mandatory, do not delete it.


#include <stdlib.h>
#include <time.h>
#include "lrun.h"

// Function to return a random article index
int getRandomArticleIndex(int max) {
    if (max > 0) {
        srand(time(NULL));  // Seed random number generator
        return rand() % max; // Get a random number between 0 and max-1
    }
    return -1; // Return -1 if no valid articles
}

// VuGen Action function to call the C function
void Action1() {
    // Get the number of search results from a LoadRunner parameter
    int maxArticles = atoi(lr_eval_string("{ArticleCount}")); 
    
    // Generate a random article index
    int randomIndex = getRandomArticleIndex(maxArticles);

    // Save the result to a LoadRunner parameter
    char buffer[10];
    sprintf(buffer, "%d", randomIndex);
    lr_save_string(buffer, "RandomIndex");

    // Print to LoadRunner logs
    lr_output_message("Selected Random Article Index: %d", randomIndex);
}